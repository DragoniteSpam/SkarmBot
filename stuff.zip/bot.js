"use strict";
// load discordie object
const discordie = require("discordie");
const twitch = require('twitch-get-stream')('jm6wh6ctwjg97ljlffp8ds062uzkd7');
const fs=require("fs"), ini=require("ini");
// create the discord client obj
const client = new discordie({autoReconnect:true});
const events = discordie.Events;

// Classes

class User {
	constructor(name, discriminator){
		this.name=name;
		this.discriminator=discriminator;
		this.swears=0;
		this.slaps=0;
		this.eyan=0;
		this.toilet=0;
		
		this.actions=0;
		this.questions=0;
		this.exclamations=0;
		
		this.lines=0;
		this.secretWord=0;
		this.secretWordAdd=0;
	}
}

// Images

var waifus=[
	"bunny.jpg",
	"cat.jpg",
	"cat2.jpg",
	"cat3.jpg",
	"chicken.jpg",
	"chipmunk.jpg",
	"dogs.png",
	"mouse.jpg",
	"squirrel.png"
	];

var cats=[
	"cat1.jpg",
	"cat2.jpg",
	"cat3.jpg",
	"cat4.jpg",
	"cat5.jpg",
	"cat6.jpg",
	"cat7.jpg",
	"cat8.jpg",
	"cat9.jpg",
	]

// Banned words
var banned=[
	["whore", "Potty mouth!", "SKITTY"],
	["slut", "Potty mouth!", "SKITTY"],
	["cunt", "Potty mouth!", "SKITTY"],
	["nigger", "wow r00d", "SKITTY"],
	["fuck", "Potty mouth!", "SKITTY"],
	["pussbag", "Potty mouth!", "DELCATTY"],
	["jacking off", "Get a room!", "SKITTY"],
	//["gummy x dragonite", "xnx", "wut"],
	//["dragonite x gummy", "xnx", "no"]
]

var bannedGummy=[
	["vive", "treason!"],
	//["truck", "gummy told me to ban this one"]
	//["hides behind", "no you don't"],
	//["musket", "this is real life, knucklehead"],
	//["bayonet", "i swear to god gummy, i will stab you with one"]
]

var bannedDragonite=[
	["toilet", "that's not very sanitary"],
	["to!let", "stop evading the censor ლ(ಠ益ಠლ)"],
]

// Leetspeak
var leetChars=[
	["!", "i"],
	["1", "i"],
	["@", "a"],
	["4", "a"],
	["5", "s"],
	["$", "s"],
	["9", "g"],
	["7", "t"],
	["0", "o"],
	["3", "e"],
]

// These get cleared every once in a while
var deletionQueue=[];
var deletionQueueLong=[];

// Load up the stats
var stats=ini.parse(fs.readFileSync('stats.ini', 'utf-8'));
var userTable={};
utilityCreateUserTable();

// assume the stream is online until proven otherwise, that way it doesn't keep
// notifying everyone if it crashes or restarts due to changes
var streamState=true;
var streamHasNotifiedDate=0;

// There are some things that need doing on a regular basis
var timer15 = setInterval(function(){
	twitchGetIsLive();
	twitchSendStatusMessage();
	censorClearDeletionQueue();
}, 15000);

var timer60 = setInterval(function(){
	//censorClearDeletionQueueLong();
	utilitySaveStats();
}, 60000);

// I still don't actually know what this is for?
client.connect({
token: "MzE5MjkxMDg2NTcwOTEzODA2.DA-zPQ._NYnKlrxK1jM6py2M9AXIxdX5wo"
});

// What happens when you first connect
client.Dispatcher.on(events.GATEWAY_READY, e => {
	console.log("Connected as " + client.User.username+". Yippee!");
	client.User.setGame("Type \"e!help\" !");
	twitchGetIsLive();
	twitchGetLastStreamDate();
});

client.Dispatcher.on(events.MESSAGE_UPDATE, e=> {
	if (e.message!=null){
		censor(e.message);
	}
});

client.Dispatcher.on(events.MESSAGE_CREATE, e=> {
	var message=e.message.content.toLowerCase();
	// Help
	if (message=="e!help"){
		helpHelpHelp(e);
	} else if (message=="e!help eyansays"){
		helpEyanSays(e);
	} else if (message=="e!help eyantwitch"){
		helpEyanTwitch(e);
	} else if (message=="e!help eyanlol"){
		helpEyanLol(e);
	} else if (message=="e!help eyanmisc"){
		helpEyanMisc(e);
	} else if (message=="e!help eyanpictures"){
		helpEyanPictures(e);
	} else if (message=="e!help eyancredits"){
		helpEyanCredits(e);
	// Utilities
	} else if (message=="e!size"){
		utiliyLineCount(e);
	} else if (message=="e!all"){
		//utilityDumpServer(e);
		e.message.channel.sendMessage("This has been turned off to preserve sanity. If you really need to use it, go bother Dragontie#7992 to turn it back on.");
		//utilityDumpServer(e);
	} else if (message=="e!stats"){
		utilityStats(e);
	} else if (message=="e!ping"){
		utilityPing(e);
	// Eyan Says
	} else if (message.startsWith("e!add")){
		add(e.message);
	} else if (message.startsWith("e!says")){
		sendRandomLine(e.message);
	} else if (message=="e!test"){
		e.message.channel.sendMessage(e.message.author.username+" can submit messages: "+userHasPermission(e.message.author, e.message.channel));
	} else if (message=="e!react"){
		react(e.message);
	// Twitch
	} else if (message=="e!live"){
		twitchGetIsLive(e.message.channel);
	// Lol
	} else if (message=="e!will"){
		annoyWill(e.message.channel);
	// Pictures
	} else if (message=="e!waifu"){
		waifuSend(e.message.channel);
	} else if (message=="e!cat"){
		catSend(e.message.channel);
	}
	// Literally everything else
	else {
		statsWillOfD(e.message);
		censor(e.message);
		STATS(e.message);
		REACT(e.message);
	}
});

/*
 ********************
 *     Eyan Says    *
 ********************
 */

function add(message){
	var msg=message.content.replace("e!add ", "");
	
	if (msg.startsWith("react")){
		saveLine(message, "reactions.txt", msg.replace("react ", ""));
	} else if (message.mentions.length==0){
		saveLine(message, "line.txt", msg);
	} else {
		var user=message.mentions[0];
		saveLine(message, "./quotes/"+user.username+".txt", msg.substring(msg.indexOf(" ")).trim());
	}
}

// Checks to see if the user is allowed to submit messages to EyanSays
function userHasPermission(author, channel){
	var value=author.can(discordie.Permissions.General.KICK_MEMBERS, channel);
	return value||author.username=="Dragonite";
}

// Send a random line
function sendRandomLine(message){
	var str=message.content.replace("e!says", "");
	if (str==""){
		sendRandomFileLine("line.txt", message.channel);
	} else if (message.mentions.length==0){
		sendRandomFileLine("./quotes/"+str.trim()+".txt", message.channel);
	} else {
		var user=message.mentions[0];
		sendRandomFileLine("./quotes/"+user.username+".txt", message.channel);
	}
}

// Saves a line to the line file
function saveLine(message, filename, string){
	if (userHasPermission(message.author, message.channel)){
		fs.appendFile(filename, string+"\r\n", (err) => {
			if (err){
				throw err;
			}
			console.log(string+" was written to "+filename+".");
		});
		message.channel.sendMessage("Added!");
	} else {
		message.channel.sendMessage(message.author.username+": you don't have permission to add quotes. Sorry.");
	}
}

// Pulls a random line from the text file
function sendRandomFileLine(filename, channel){
	var lines;
	fs.readFile(filename, function(err, data){
		if(err){
			channel.sendMessage("No quotes for that user!");
		} else {
			lines = data.toString().split('\n');
			var line="";
			do {
				line=lines[Math.floor(Math.random()*lines.length)];
			} while (line=="");
			channel.sendMessage(line);
		}
	})
}

// Twitch reactions
function react(message){
	sendRandomFileLine("reactions.txt", message.channel);
}

/*
 ********************
 *   Twitch Stuff   *
 ********************
 */

// Checks if Zeal is online. If he's gone online, it sends an announcement.
function twitchSendStatusMessage(){
	if (streamState){
		var date=new Date();
		if (twitch12HoursElapsed(date, streamHasNotifiedDate)){
			streamHasNotifiedDate=new Date();
			fs.writeFile("./stuff/streamDate.txt", streamHasNotifiedDate);
			client.Channels.get("305488106050813954").sendMessage("@everyone Zeal has gone online! \n https://www.twitch.tv/kingofzeal");
		}
	}
}

function twitch12HoursElapsed(newDate, oldDate){
	var seconds=(newDate-oldDate)/1000;
	var minutes=seconds/60;
	var hours=minutes/60;
	return (hours>12);
}

// I'm sure there's a better way to do this.
function twitchGetIsLive(channel){
	twitch.get('kingofzeal').then(function(streams) {
		if (channel!=null){
			channel.sendMessage("Zeal is live!\n https://www.twitch.tv/kingofzeal");
		}
		streamState=true;
	}).catch(function(error) {
		if (channel!=null){
			channel.sendMessage("Zeal is not live //:");
		}
		streamState=false;
	});
	// can't simply return a value here because this is an asyncrhonous function ლ(ಠ益ಠლ)
}

function twitchGetLastStreamDate(){
	fs.readFile("./stuff/streamDate.txt", function(err, data){
		if(err){
			
		} else {
			var date = data.toString().split('\n');
			streamHasNotifiedDate=new Date(date);
		}
	})
}

/*
 ********************
 *     Lol Stuff    *
 ********************
 */

// Stuff he says.
function annoyDragonite(channel){
	 var responses=["You rang?"];
		// add more responses down here
	channel.sendMessage(responses[Math.floor(Math.random()*responses.length)]);
}

// Stats printout.
function annoyWill(channel){
	var lol=stats.WillOfD.lol;
	var xd=stats.WillOfD.xd;
	var w=stats.WillOfD.w;
	var messages=stats.WillOfD.messages;
	if (messages==0){
		channel.sendMessage("\\*\\*\\*Will has not recorded any messages yet.\\*\\*\\*");
	} else {
		channel.sendMessage("```Percentage of WillOfD's messages that contain \"lol:\""+(100*lol/messages).toFixed(2)+"%\n"+
			"Percentage of WillOfD's messages that contain \"XD:\" "+(100*xd/messages).toFixed(2)+"%\n"+
			"Percentage of WillOfD's messages that contain \"^w^:\" "+(100*w/messages).toFixed(2)+"%\n\n"+
			"WillOfD's total messages: "+messages+"```");
	}
}

/*
 ********************
 *       Stats      *
 ********************
 */

// Because I swear she says this in every single message (sometimes both).
function statsWillOfD(message){
	if (messageAuthorEquals(message, "willofd2011", 9368)){
		var text=message.content.toLowerCase();
		if (text.includes("lol")){
			stats.WillOfD.lol++;
		}
		if (text.includes("xd")){
			stats.WillOfD.xd++;
		}
		if (text.includes("^w^")){
			stats.WillOfD.w++;
		}
		stats.WillOfD.messages++;
		fs.writeFileSync('stats.ini', ini.stringify(stats));
	}
}

function STATS(message){
	var string=message.content.toLowerCase();
	var usernameString=authorString(message.author);
	var user;
	if (usernameString in userTable){
		user=userTable[usernameString];
	} else {
		user=new User(message.author.username);
		userTable[usernameString]=user;
	}
	if (string.includes("slap")&&utilityIsAction(string)){
		user.slaps++;
	}
	if (string.includes("eyan")||string.includes("zeal")){
		user.eyan++;
	}
	if (string.includes("toilet")){
		user.toilet++;
	}
	if (utilityIsAction(string)){
		user.actions++;
	}
	if (string.endsWith("?")){
		user.questions++;
	}
	if (string.endsWith("!")){
		user.exclamations++;
	}
	user.lines++;
}

/*
 ********************
 *     Reactions    *
 ********************
 */

function REACT(message){
	if (utilityMentionsMe(message)&&utilityIsAction(message.content)){
		var newString=message.content.substring(1);
		if (newString.startsWith("slaps")){
			message.channel.sendMessage("Ow . . .");
		}
	}
}

/*
 ********************
 *      Censor      *
 ********************
 */

// Basic censor. Built around string.includes. Not recommended for serious use.
 
function censor(message){
	if (message.channel!=client.Channels.get("311402910820859914")){
		censorText(message.content, message.channel, message.author, message, "");
	}
}

// The actual censor
function censorText(text, channel, author, message, redactMessage){
	var newMessage=text.toLowerCase();
	var toDelete=-1;
	for (var i=0; i<banned.length; i++){
		if (newMessage.includes(banned[i][0])){
			if (redactMessage.length==0){
				newMessage=replaceAll(newMessage, banned[i][0], banned[i][2]);
			} else {
				newMessage=redactMessage;
			}
			toDelete=i;
		}
	}
	if (toDelete>-1){
		if (newMessage.length>320){
			newMessage=newMessage.slice(0, 320)+"...";
		}
		channel.sendMessage(banned[toDelete][1]+"\n`"+author.username+": "+newMessage+"`").then(e => censorMessageDeletionQueueLong(e));
		censorUpdateSwearTable(author);
		message.delete();
		return true;
	} else {
		// Other special cases
		if (authorEquals(author, "supergummying", 7574)){
			for (var i=0; i<bannedGummy.length; i++){
				if (text.toLowerCase().includes(bannedGummy[i][0])){
					// Delete the message after a certain amount of time
					channel.sendMessage(bannedGummy[i][1]).then(e => censorMessageDeletionQueue(e));
					message.delete();
					return true;
				}
			}
		} else if (authorEquals(author, "dragonite", 7992)){
			for (var i=0; i<bannedDragonite.length; i++){
				if (text.toLowerCase().includes(bannedDragonite[i][0])){
					// Delete the message after a certain amount of time
					channel.sendMessage(bannedDragonite[i][1])/*.then(e => censorMessageDeletionQueue(e))*/;
					message.delete();
					return true;
				}
			}
		}
	}
	return false;
}

// Adds a message to the short-term deletion log.
function censorMessageDeletionQueue(message){
	deletionQueue.push(message);
}

// Clears the short-term deletion log.
function censorClearDeletionQueue(){
	for (var i=0; i<deletionQueue.length; i++){
		deletionQueue[i].delete();
	}
	deletionQueue=[];
}

// Adds a message to the long-term deletion log.
function censorMessageDeletionQueueLong(message){
	deletionQueueLong.push(message);
}

// Clears the long-term deletion log.
function censorClearDeletionQueueLong(){
	for (var i=0; i<deletionQueueLong.length; i++){
		deletionQueueLong[i].delete();
	}
	deletionQueueLong=[];
}

// Updates the swear table, and saves it

function censorUpdateSwearTable(user){
	var n=authorString(user);
	if (!(n in userTable)){
		userTable[n]=new User(user.username, user.discriminator);
		userTable[n].swears=1;
	} else {
		userTable[n].swears++;
	}
	utilitySaveStats();
}

/*
 ********************
 *   Picture stuff  *
 ********************
 */

function waifuSend(channel){
	channel.uploadFile("waifus\\"+waifus[Math.floor(Math.floor(Math.random()*waifus.length))]);
}

function catSend(channel){
	channel.uploadFile("cats\\"+cats[Math.floor(Math.floor(Math.random()*cats.length))]);
}

/*
 ********************
 *     Utilities    *
 ********************
 */
 
 // Loads in the stored values from the swear table.

function utilityCreateUserTable(){
	var lines;
	fs.readFile("stats.csv", function(err, data){
		if(err){
			throw err;
		}
		lines = data.toString().split('\n');
		for (var i=0; i<lines.length; i++){
			if (lines[i].includes(",undefined")){
			} else {
				var spl=lines[i].split(",");
				
				var user=new User(spl[0].split("#")[0], spl[0].split("#")[1]);
				userTable[spl[0]]=user;
				user.swears=Number(spl[1]);
				user.slaps=Number(spl[2]);
				user.eyan=Number(spl[3]);
				user.toilet=Number(spl[4]);
				
				user.actions=Number(spl[5]);
				user.questions=Number(spl[6]);
				user.exclamations=Number(spl[7]);
				
				user.lines=Number(spl[8]);
				user.secretWord=Number(spl[9]);
				user.secretWordAdd=Number(spl[10]);
			}
		}
	});
}
 
 // Saves all of the stats
 
 function utilitySaveStats(){
	var saveString="";
	for (var n in userTable){
		var user=userTable[n];
		saveString=saveString+n+","+user.swears+
			","+user.slaps+","+user.eyan+","+user.toilet+
			","+user.actions+","+user.questions+","+user.exclamations+
			","+user.lines+","+user.secretWord+","+user.secretWordAdd+
			"\r\n";
	}
	fs.writeFile("stats.csv", saveString, function(err) {
		if(err) {
			return console.log(err);
		}
	});
 }

// Utility that prints out the number of lines in the bot's learned database.
function utiliyLineCount(e){
	var lines;
	fs.readFile("line.txt", function(err, data){
		if(err){
			e.message.channel.sendMessage("Something blew up. Oh noes! @Dragonite#7992");
			throw err;
		}
		lines = data.toString().split('\n');
		e.message.channel.sendMessage(lines.length+" lines in Eyan's quote log.");
	})
}

// Prints out the high score table for the censor
function utilityStats(e){
	var statsString="SOME INANE STATS THAT DRAGONITE COLLECTS";
	var highscoreList=__createDefaultHighScoreList();
	statsString+=utilityAppendHR();		// Slaps
	highscoreList.sort(function(a, b){
		return b.slaps-a.slaps;
	});
	statsString+=highscoreList[0].name+" was rather slap happy, dishing out a solid backhand "+highscoreList[0].slaps+" times.\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].slaps, highscoreList[1].slaps)+", using the move "+highscoreList[1].slaps+" times.";
	statsString+=utilityAppendHR();		// Toilets
	highscoreList.sort(function(a, b){
		return b.toilet-a.toilet;
	});
	statsString+=highscoreList[0].name+" has a rather peculiar obsession with toilets, saying the word "+highscoreList[0].toilet+" times.\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].toilet, highscoreList[1].toilet)+", with "+highscoreList[1].toilet+" in total.";
	statsString+=utilityAppendHR();		// Eyan
	highscoreList.sort(function(a, b){
		return b.eyan-a.eyan;
	});
	statsString+=highscoreList[0].name+" was eager to proclaim their love for the King, saying his name a whopping "+highscoreList[0].eyan+" times.\n";
	statsString+=highscoreList[1].name+" was also "+utilityZealString()+", with "+highscoreList[1].eyan+" references to the King.";
	statsString+=utilityAppendHR();		// Actions
	highscoreList.sort(function(a, b){
		return b.actions-a.actions;
	});
	statsString+=highscoreList[0].name+" greatly enjoyed role playing, writing "+highscoreList[0].actions+" lines as actions.\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].actions, highscoreList[1].actions)+", with "+highscoreList[1].actions+" in total.";
	statsString+=utilityAppendHR();		// Questions
	highscoreList.sort(function(a, b){
		return b.questions-a.questions;
	});
	statsString+=highscoreList[0].name+" has an insatiable thirst for knowledge, "+highscoreList[0].questions+" questions in total.\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].questions, highscoreList[1].questions)+", with "+highscoreList[1].questions+" all told.";
	statsString+=utilityAppendHR();		// Exclamations
	highscoreList.sort(function(a, b){
		return b.exclamations-a.exclamations;
	});
	statsString+="People probably wish "+highscoreList[0].name+" would pipe down a bit, after hearing them shout "+highscoreList[0].exclamations+" times!\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].exclamations, highscoreList[1].exclamations)+", raising their voice on "+highscoreList[1].exclamations+" occasions.";
	statsString+=utilityAppendHR();		// Lines
	highscoreList.sort(function(a, b){
		return b.lines-a.lines;
	});
	statsString+=highscoreList[0].name+" talks a bit too much, writing "+highscoreList[0].lines+" total lines since joining the server.\n";
	statsString+=highscoreList[1].name+" was "+utilityComparisonString(highscoreList[0].lines, highscoreList[1].lines)+", with "+highscoreList[1].lines+" of the things.\n\n";
	statsString+="*Note that this only counts stats collected while Dragonite's computer was turnd on.";
	e.message.channel.sendMessage("```"+statsString+"```");
}
	
function utilityComparisonString(a, b){
	var f=b/a;
	var responses;
	if (f>0.9){
		responses=["a close second", "right there", "vying for the honor", "right on their heels", "in close competition"];
	} else if (f>0.5){
		responses=["not far too behind", "making an effort", "up and coming", "within sight"];
	} else {
		responses=["nowhere in sight", "not trying very hard", "only mildly interested"];
	}
	return responses[Math.floor(Math.random()*responses.length)];
}

function utilityZealString(){
	var responses=["enthralled by the royalty", "in awe"]
	return responses[Math.floor(Math.random()*responses.length)];
}

// Dumps all of the people in the userTable without sorting it.
function __createDefaultHighScoreList(){
	var list=[];
	for (o in userTable){
		if (userTable[o].name.length>0){
			var user=userTable[o];
			if (user.name!="Tatsumaki"&&user.discriminator!=8792){
				list.push(userTable[o]);
			}
		}
	}
	return list;
}

// append a long line of dashes
function utilityAppendHR(){
	return "\n-----------------\n";
}

// Master wants to play ping pong.
function utilityPing(e){
	var now=Date.now();
	e.message.channel.sendMessage("o3o").then(e => utilityPingTimeElapsed(e, now));
	console.log("Pinged the bot, blah, blah.");
}

// Is a message an action?
function utilityIsAction(string){
	var first=string.charAt(0);
	if (first!="*"&&first!="_"){
		return false;
	}
	return string.endsWith(first);
}

// Follow-up for utilityPing
function utilityPingTimeElapsed(message, now){
	var n=Date.now()-now;
	message.edit(message.content+": `"+n+" ms`");
}

// Mentions the bot?
function utilityMentionsMe(message){
	for (var i=0; i<message.mentions.length; i++){
		if (message.mentions[i].username==client.User.username&&message.mentions[i].discriminator==client.User.discriminator){
			return true;
		}
	}
	return false;
}

// Utility that dumps all of the messages in a server.
function utilityDumpServer(e){
	console.log("***"+e.message.channel.name+"***");
	fetchMessagesEx(e.message.channel, 100000);
}

// fetch more messages just like Discord client does
function fetchMessagesEx(channel, left) {
  // message cache is sorted on insertion
  // channel.messages[0] will get oldest message
  var before = channel.messages[0];
  return channel.fetchMessages(Math.min(left, 100), before)
         .then(e => onFetch(e, channel, left));
}

// What to do when you fetch a batch of messages.
function onFetch(e, channel, left) {
	if (!e.messages.length){
		return Promise.resolve();
	}
	left -= e.messages.length;
	console.log(`Received ${e.messages.length}, left: ${left}`);
	for (var i=0; i<e.messages.length; i++){
		var message=e.messages[i];
		/////////
		STATS(message);
		/////////
		var str=message.author.username+":\t"+e.messages[i].content+"\r\n"
		fs.appendFile(channel.name+".txt", str, (err) => {
			if (err){
				throw err;
			}
		});
	}
	if (left <= 0){
		return Promise.resolve();
	}
	return fetchMessagesEx(channel, left);
}

// Checks to see if a message was written by a certain perosn.
function messageAuthorEquals(message, username, discriminator){
	return authorEquals(message.author, username, discriminator);
}

function authorEquals(author, username, discriminator){
	return author.username.toLowerCase()==username&&author.discriminator==discriminator;
}

function authorString(user){
	return user.username+"#"+user.discriminator;
}

// Because for some inane reason JavaScript does not include this on its own. Inefficient.
function replaceAll(string, toReplace, newString){
	var t=string;
	while (t.includes(toReplace)){
		t=t.replace(toReplace, newString);
	}
	return t;
}

// This helps with the censor and maybe a few other things
function utilityDeLeetspeak(text){
	var newText=text;
	for (var i=0; i<leetChars.length; i++){
		newText=replaceAll(newText, leetChars[i][0], leetChars[i][1]);
	}
	return newText;
}

/*
 ********************
 *       Help       *
 ********************
 */

// Prints an introduction to EyanSays
function helpHelpHelp(e){
	var message=client.User.username+" is a Discord bot for the Kingdom/Harem of Zeal. There's a few things it does. "+
		"Type one of the following to learn more:\n\n"+
		"e!help EyanSays\n"+
		"e!help EyanTwitch\n"+
		"e!help EyanLol\n"+
		"e!help EyanPictures\n"+
		"e!help EyanMisc\n\n"+
		"e!help EyanCredits\n\n"+
		"All commands are case insensitive.";
	e.message.channel.sendMessage("```"+message+"```");
}

// Introduction to main EyanSays
function helpEyanSays(e){
	var message="EyanSays\n\n"+
		"The bot stores all of the weird things that the King of Zeal says during "+
		"his Twitch streams. People with kicking boots can add quotes with \"e!add <message>\"."+
		"To grab a random quote out of the archive, type \"e!says\". "+
		"Use \"e!size\" to see how many lines have been recorded.\n\n"+
		"If the King of Zeal says something you think is worthy of being added to the archive, ask "+
		"someone with kicking boots to do it for you (or bother Dragonite#7992 about it)."+
		"If you're not sure if you have kicking boots or not, you can check with \"e!test\" (but you "+
		"probably don't).\n\n"+
		"\"e!react\" is a similar command that can get a random Twitch reaction.\n\n"+
		"In addition, you can type \"e!says <username>\" or \"e!add <username>\" to add or get a quote for a specific user.";
		
	e.message.channel.sendMessage("```"+message+"```");
}

// Introduction to EyanTwitch
function helpEyanTwitch(e){
	var message="Twitch Stuff\n\n"+
		client.User.username+" will monitor the state of Zeal's Twitch stream, and can notify the server "+
		"when he goes live. If you want to find out if he's live or not, type \"e!live\" and "+client.User.username+" "+
		"will inform you."
	e.message.channel.sendMessage("```"+message+"```");
}

// Introduction to EyanLol
function helpEyanLol(e){
	var message="Poking fun at people\n\n"+
		client.User.username+" has a few commands for messing with people. Currently available are:\n\n"+
		"e!will\n\n"+
		"Exactly how to get your own command is a secret, and the answer is probably not \"ask for one.\"";
	
	e.message.channel.sendMessage("```"+message+"```");
}
	
// Introduction to EyanPictures
function helpEyanPictures(e){
	var message="Miscellaneous Stuff\n\n"+
		client.User.username+" can embed a few fancy images into the channel.\n\n"+
		"e!waifu\n"+
		"e!cat";
	e.message.channel.sendMessage("```"+message+"```");
}

// Introduction to EyanMisc
function helpEyanMisc(e){
	var message="Miscellaneous Stuff\n\n"+
		client.User.username+" can do a few other things, too.\n\n"+
		"e!ping\n"+
		"e!stats";
	e.message.channel.sendMessage("```"+message+"```");
}

// Credits, obviously
function helpEyanCredits(e){
	var message="Credits\n\n"+
		"***"+client.User.username+"***\n\n"+
		"Creator: Dragonite#7992\n"+
		"Version: 1.2.0\n"+
		"Library: Discordie\n\n"+
		"https://www.youtube.com/c/dragonitespam \n";
	e.message.channel.sendMessage("```"+message+"```");
}
